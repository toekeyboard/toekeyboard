DirectDictaphone
================

Simplified Android dictaphone for recording short notes while driving or walking.

Compiled app is available on https://play.google.com/store/apps/details?id=fr.herverenault.directdictaphone and on F-Droid https://f-droid.org/repository/browse/?fdid=fr.herverenault.directdictaphone

I made this small app for my own use, on Android 2.3 initially.

![this is how it looks](directdictaphone.jpg)

